plugins { id("com.android.application") }

android {
    namespace = "com.sokatira.equipo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sokatira.equipo"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.activity:activity:1.10.1")
    implementation("androidx.webkit:webkit:1.12.1")
}
