# Sokatira Android

Proyecto Android de la aplicación completa.

## Incluye
- Calendario como pantalla inicial.
- Competiciones con fechas, colores, categorías y equipos.
- Crear, editar y eliminar con confirmación y deshacer.
- Participantes, plantillas, comparador y gráficos.
- Guardado local persistente mediante Web Storage del WebView.
- Exportación e importación de copia de seguridad JSON mediante el selector de documentos de Android.
- Configuración de copia automática y transferencia de dispositivo.

## Generar APK
1. Abre la carpeta `SokatiraAndroidCompleta` en Android Studio.
2. Espera a que termine la sincronización de Gradle.
3. Usa `Build > Generate App Bundles or APKs > Generate APKs`.
4. El APK de prueba aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

Para publicar, usa `Build > Generate Signed Bundle / APK` y firma la aplicación con tu clave.

## Identidad de la aplicación
- Nombre visible: **Sokatira Taldeak**
- Icono propio normal y redondo para el lanzador de Android.
- Versión: 1.1 (código 2).
